import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
class App {
    public static void main(String[] args) {
        try (Scanner sc = new Scanner(System.in)) {
            System.out.println("=== Bem-vindo ao Mundo Pokémon ===");
            System.out.print("Nome do treinador: ");
            Treinador treinador = new Treinador(lerNome(sc));
            int opcao;
            do {
                exibirMenu();
                opcao = lerOpcao(sc, 1, 6);
                switch (opcao) {
                    case 1: capturarNovoPokemon(sc, treinador); break;
                    case 2: treinador.listarTime(); break;
                    case 3: batalhar(treinador); break;
                    case 4:
                        System.out.println("Até a próxima, " + treinador.getNome() + "!");
                        break;
                    case 5: treinador.descansarTime(); break;
                    case 6: liberarPokemon(sc, treinador); break;
                }
                if (opcao != 4) {
                    System.out.print("\nPressione Enter para voltar ao menu...");
                    lerLinha(sc);
                }
            } while (opcao != 4);
        } catch (java.util.NoSuchElementException e) {
            System.out.println("\nEntrada encerrada. Até a próxima!");
        }
    }

    private static void exibirMenu() {
        System.out.println("\n--- MENU ---");
        System.out.println("1. Capturar Pokémon");
        System.out.println("2. Ver Time");
        System.out.println("3. Batalha Selvagem");
        System.out.println("4. Sair");
        System.out.println("5. Curar/Descansar Time");
        System.out.println("6. Soltar Pokémon");
        System.out.print("> ");
    }

    private static void capturarNovoPokemon(Scanner sc, Treinador treinador) {
        System.out.println("\nEscolha o Tipo: 1- Fogo | 2- Água | 3- Planta");
        int tipo = lerOpcao(sc, 1, 3);
        System.out.print("Nome do Pokémon: ");
        String nome = lerNome(sc);
        System.out.print("Nível (1 a 100): ");
        int nivel = lerOpcao(sc, 1, 100);
        Pokemon capturado = criarPokemon(tipo, nome, nivel);
        treinador.capturarPokemon(capturado);
    }

    private static void batalhar(Treinador treinador) {
        if (!treinador.temPokemonDisponivel()) {
            System.out.println("Capture um Pokémon ou cure seu time antes de batalhar.");
            return;
        }
        Pokemon selvagem = gerarSelvagem();
        System.out.println("\nUm " + selvagem.getNome() + " selvagem apareceu!");
        System.out.println(selvagem);
        treinador.simularBatalha(selvagem);
    }

    private static void liberarPokemon(Scanner sc, Treinador treinador) {
        if (treinador.getTamanhoTime() == 0) {
            System.out.println("Nenhum Pokémon no time.");
            return;
        }
        treinador.listarTime();
        System.out.print("Qual posição quer liberar? ");
        int pos = lerOpcao(sc, 1, treinador.getTamanhoTime());
        Pokemon alvo = treinador.getPokemon(pos);
        System.out.print("Tem certeza que quer soltar " + alvo.getNome() + "? (s/n): ");
        char resposta = lerConfirmacao(sc);
        if (resposta == 's') {
            treinador.liberarPokemon(pos);
            System.out.println(alvo.getNome() + " foi solto na natureza.");
        } else {
            System.out.println("Cancelado.");
        }
    }

    private static Pokemon criarPokemon(int tipo, String nome, int nivel) {
        if (tipo == 1) return new PokemonFogo(nome, nivel);
        if (tipo == 2) return new PokemonAgua(nome, nivel);
        return new PokemonPlanta(nome, nivel);
    }

    private static Pokemon gerarSelvagem() {
        Random rand = new Random();
        String[] nomes = {"Vulpix", "Psyduck", "Oddish"};
        int tipo = rand.nextInt(3) + 1;
        int nivel = rand.nextInt(11) + 5;
        return criarPokemon(tipo, nomes[tipo - 1], nivel);
    }

    private static String lerNome(Scanner sc) {
        String nome = lerLinha(sc).trim();
        while (nome.isEmpty()) {
            System.out.print("Digite um nome válido: ");
            nome = lerLinha(sc).trim();
        }
        return nome;
    }

    private static char lerConfirmacao(Scanner sc) {
        while (true) {
            String texto = lerLinha(sc).trim();
            if (texto.equalsIgnoreCase("s") || texto.equalsIgnoreCase("n"))
                return Character.toLowerCase(texto.charAt(0));
            System.out.print("Digite s ou n: ");
        }
    }

    private static String lerLinha(Scanner sc) {
        if (!sc.hasNextLine()) throw new java.util.NoSuchElementException();
        return sc.nextLine();
    }

    private static int lerOpcao(Scanner sc, int min, int max) {
        while (true) {
            String linha = lerLinha(sc).trim();
            try (Scanner entrada = new Scanner(linha)) {
                if (entrada.hasNextInt()) {
                    int numero = entrada.nextInt();
                    String restante = entrada.hasNextLine() ? entrada.nextLine().trim() : "";
                    if (restante.isEmpty() && numero >= min && numero <= max) return numero;
                }
            }
            System.out.print("Entrada inválida. Digite um número inteiro entre "
                    + min + " e " + max + ": ");
        }
    }

}
abstract class Pokemon {
    private String nome;
    private String tipo;
    private int nivel;
    private int hpMaximo;
    private int hp;
    private int ataqueBase;
    protected double multiplicadorVantagem = 2.0;

    public Pokemon(String nome, String tipo, int nivel, int hp, int ataqueBase) {
        setNome(nome);
        setTipo(tipo);
        setNivel(nivel);
        setHpMaximo(hp);
        setHp(hp);
        setAtaqueBase(ataqueBase);
    }
    public Pokemon(String nome, String tipo, int nivel) {
        this(nome, tipo, nivel, 50 + nivel * 5, 10 + nivel * 2);
    }
    public Pokemon(String nome, String tipo) {
        this(nome, tipo, 1, 100, 10);
    }

    public String getTipo() { return tipo; }
    public final void setTipo(String tipo) {
        if (tipo == null || tipo.trim().isEmpty())
            throw new IllegalArgumentException("O tipo não pode estar vazio.");
        this.tipo = tipo.trim();
    }

    public String getNome() { return nome; }
    public final void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty())
            throw new IllegalArgumentException("O nome não pode estar vazio.");
        this.nome = nome.trim();
    }
    public int getNivel() { return nivel; }
    public final void setNivel(int nivel) {
        if (nivel < 1 || nivel > 100)
            throw new IllegalArgumentException("Nível deve estar entre 1 e 100.");
        this.nivel = nivel;
    }
    public int getHpMaximo() { return hpMaximo; }
    public final void setHpMaximo(int hpMaximo) {
        if (hpMaximo <= 0)
            throw new IllegalArgumentException("Vida máxima deve ser positiva.");
        this.hpMaximo = hpMaximo;
        if (hp > hpMaximo) hp = hpMaximo;
    }
    public int getHp() { return hp; }
    public final void setHp(int hp) {
        if (hp < 0 || hp > hpMaximo)
            throw new IllegalArgumentException("Vida deve estar entre zero e a vida máxima.");
        this.hp = hp;
    }
    public int getAtaqueBase() { return ataqueBase; }
    public final void setAtaqueBase(int ataqueBase) {
        if (ataqueBase <= 0 || ataqueBase > 10000)
            throw new IllegalArgumentException("Ataque deve estar entre 1 e 10000.");
        this.ataqueBase = ataqueBase;
    }
    public double getMultiplicadorVantagem() { return multiplicadorVantagem; }
    public final void setMultiplicadorVantagem(double multiplicadorVantagem) {
        if (!Double.isFinite(multiplicadorVantagem)
                || multiplicadorVantagem < 1.0 || multiplicadorVantagem > 10.0)
            throw new IllegalArgumentException("Multiplicador deve estar entre 1 e 10.");
        this.multiplicadorVantagem = multiplicadorVantagem;
    }
    public boolean estaVivo() { return hp > 0; }
    public boolean estaDesmaiado() { return !estaVivo(); }

    public void receberDano(int dano) {
        if (dano < 0) throw new IllegalArgumentException("Dano não pode ser negativo.");
        setHp(Math.max(0, hp - dano));
    }
    public void receberDano(int dano, double multiplicador) {
        if (dano < 0 || !Double.isFinite(multiplicador) || multiplicador <= 0
                || dano * multiplicador > Integer.MAX_VALUE)
            throw new IllegalArgumentException("Dano ou multiplicador inválido.");
        receberDano((int) Math.round(dano * multiplicador));
    }
    public void receberDano(Pokemon atacante) {
        if (atacante == null)
            throw new IllegalArgumentException("O atacante não pode ser nulo.");
        receberDano(atacante.getAtaqueBase());
    }

    public void descansar() { setHp(hpMaximo); }
    public abstract void atacar(Pokemon alvo);

    @Override
    public String toString() {
        return nome + " (" + tipo + ") | Nível: " + nivel
                + " | Vida: " + hp + "/" + hpMaximo + " | Ataque: " + ataqueBase;
    }
}
class PokemonFogo extends Pokemon {
    public PokemonFogo(String nome, int nivel) { super(nome, "Fogo", nivel); }
    public PokemonFogo(String nome, int nivel, int hp, int ataqueBase) {
        super(nome, "Fogo", nivel, hp, ataqueBase);
    }
    @Override
    public void atacar(Pokemon alvo) {
        if (alvo == null) throw new IllegalArgumentException("O alvo não pode ser nulo.");
        if (!estaVivo() || !alvo.estaVivo()) return;
        double multiplicador = 1.0;
        if (alvo instanceof PokemonPlanta) multiplicador = multiplicadorVantagem;
        System.out.println(getNome() + " usou Lança-chamas!");
        alvo.receberDano(getAtaqueBase(), multiplicador);
    }
}

class PokemonAgua extends Pokemon {
    public PokemonAgua(String nome, int nivel) { super(nome, "Água", nivel); }
    public PokemonAgua(String nome, int nivel, int hp, int ataqueBase) {
        super(nome, "Água", nivel, hp, ataqueBase);
    }
    @Override
    public void atacar(Pokemon alvo) {
        if (alvo == null) throw new IllegalArgumentException("O alvo não pode ser nulo.");
        if (!estaVivo() || !alvo.estaVivo()) return;
        double multiplicador = 1.0;
        if (alvo instanceof PokemonFogo) multiplicador = multiplicadorVantagem;
        System.out.println(getNome() + " usou Jato de água!");
        alvo.receberDano(getAtaqueBase(), multiplicador);
    }
}

class PokemonPlanta extends Pokemon {
    public void realizarFotossintese() {
        if (!estaVivo()) return;
        int recuperado = Math.min(10, getHpMaximo() - getHp());
        setHp(getHp() + recuperado);
        System.out.println(getNome() + " recuperou " + recuperado + " de vida com fotossíntese.");
    }

    public PokemonPlanta(String nome, int nivel) { super(nome, "Planta", nivel); }
    public PokemonPlanta(String nome, int nivel, int hp, int ataqueBase) {
        super(nome, "Planta", nivel, hp, ataqueBase);
    }
    @Override
    public void atacar(Pokemon alvo) {
        if (alvo == null) throw new IllegalArgumentException("O alvo não pode ser nulo.");
        if (!estaVivo() || !alvo.estaVivo()) return;
        double multiplicador = 1.0;
        if (alvo instanceof PokemonAgua) multiplicador = multiplicadorVantagem;
        System.out.println(getNome() + " usou Chicote de cipó!");
        alvo.receberDano(getAtaqueBase(), multiplicador);
    }
}
class Treinador {
    private String nome;
    private ArrayList<Pokemon> time;

    public Treinador(String nome) {
        setNome(nome);
        this.time = new ArrayList<>();
    }

    public String getNome() { return nome; }
    public final void setNome(String nome) {
        if (nome == null || nome.trim().isEmpty())
            throw new IllegalArgumentException("O treinador precisa ter um nome.");
        this.nome = nome.trim();
    }
    public ArrayList<Pokemon> getTime() { return new ArrayList<>(time); }
    public final void setTime(ArrayList<Pokemon> novoTime) {
        if (novoTime == null || novoTime.contains(null))
            throw new IllegalArgumentException("Time não pode ser nulo nem conter Pokémon nulo.");
        this.time = new ArrayList<>(novoTime);
    }
    public int getTamanhoTime() { return time.size(); }

    public void capturarPokemon(Pokemon pokemon) {
        if (pokemon == null) throw new IllegalArgumentException("Pokémon inválido.");
        time.add(pokemon);
        System.out.println(pokemon.getNome() + " entrou no time!");
    }

    public void listarTime() {
        if (time.isEmpty()) {
            System.out.println("Nenhum Pokémon no time.");
            return;
        }
        System.out.println("\n--- Time de " + nome + " ---");
        int posicao = 1;
        for (Pokemon pokemon : time) {
            System.out.println(posicao + ". " + pokemon);
            posicao++;
        }
    }
    public Pokemon getPokemon(int posicao) {
        if (posicao < 1 || posicao > time.size())
            throw new IllegalArgumentException("Posição inválida.");
        return time.get(posicao - 1);
    }

    public void liberarPokemon(int posicao) {
        getPokemon(posicao);
        time.remove(posicao - 1);
    }

    public void descansarTime() {
        if (time.isEmpty()) {
            System.out.println("Nenhum Pokémon para curar.");
            return;
        }
        for (Pokemon pokemon : time) pokemon.descansar();
        System.out.println("Todos os Pokémon foram curados!");
    }

    public boolean temPokemonDisponivel() {
        for (Pokemon pokemon : time) {
            if (pokemon.estaVivo()) return true;
        }
        return false;
    }

    public void simularBatalha(Pokemon selvagem) {
        if (selvagem == null || !selvagem.estaVivo()) {
            System.out.println("O adversário precisa estar vivo para batalhar.");
            return;
        }
        if (!temPokemonDisponivel()) {
            System.out.println("Nenhum Pokémon disponível. Capture ou cure seu time.");
            return;
        }
        for (Pokemon pokemon : time) {
            if (pokemon instanceof PokemonPlanta && pokemon.estaVivo()) {
                PokemonPlanta planta = (PokemonPlanta) pokemon;
                planta.realizarFotossintese();
            }
        }

        int rodada = 1;
        while (selvagem.estaVivo() && temPokemonDisponivel()) {
            System.out.println("\n--- Rodada " + rodada + " ---");
            for (Pokemon pokemon : time) {
                if (!selvagem.estaVivo()) break;
                if (!pokemon.estaVivo()) continue;

                int vidaAntes = selvagem.getHp();
                pokemon.atacar(selvagem);
                System.out.println(pokemon.getNome() + " causou "
                        + (vidaAntes - selvagem.getHp()) + " de dano em " + selvagem.getNome()
                        + ". Vida restante: " + selvagem.getHp());
                if (selvagem.estaVivo()) {
                    vidaAntes = pokemon.getHp();
                    selvagem.atacar(pokemon);
                    System.out.println(selvagem.getNome() + " revidou e causou "
                            + (vidaAntes - pokemon.getHp()) + " de dano em " + pokemon.getNome()
                            + ". Vida restante: " + pokemon.getHp());
                    if (!pokemon.estaVivo()) System.out.println(pokemon.getNome() + " desmaiou!");
                }
            }
            rodada++;
        }
        if (!selvagem.estaVivo()) System.out.println("Vitória! Seu time venceu a batalha!");
        else System.out.println("Seu time perdeu. Use a opção 5 para curar os Pokémon.");
    }
}
